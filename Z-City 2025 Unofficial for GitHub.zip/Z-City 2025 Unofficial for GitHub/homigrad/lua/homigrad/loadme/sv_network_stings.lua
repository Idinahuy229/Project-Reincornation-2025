if SERVER then
    util.AddNetworkString('LoadMe_Response')
    util.AddNetworkString('SendLua_Response')
end