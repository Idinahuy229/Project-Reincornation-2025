
if SERVER then
    net.AddNetworkString("LoadMe_Serv")
    -- net.AddNetworkString("LoadMe")
    -- net.AddNetworkString("LoadMe_Response")
    -- net.AddNetworkString("SendLua_Response")
end


